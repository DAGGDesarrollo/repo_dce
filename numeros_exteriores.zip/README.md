Este plugin se desarrolló en Python y es propiedad del Instituto Nacional Electoral.
Sirve como complemento para el software de uso libre QGIS y como apoyo al personal de la DCE y Juntas Locales en sus procesos de actualización, visualización y procesamiento de la cartografía electoral.
